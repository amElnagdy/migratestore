<?php return array(
    'root' => array(
        'name' => 'nagdy/migratestore',
        'pretty_version' => 'dev-master',
        'version' => 'dev-master',
        'reference' => '79c700aa9afb187b39049f76d3dfc06ca1ff5cb8',
        'type' => 'wordpress-plugin',
        'install_path' => __DIR__ . '/../../',
        'aliases' => array(),
        'dev' => false,
    ),
    'versions' => array(
        'nagdy/migratestore' => array(
            'pretty_version' => 'dev-master',
            'version' => 'dev-master',
            'reference' => '79c700aa9afb187b39049f76d3dfc06ca1ff5cb8',
            'type' => 'wordpress-plugin',
            'install_path' => __DIR__ . '/../../',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
    ),
);
